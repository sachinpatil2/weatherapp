export interface Weatheritem {
  city: string;
}
